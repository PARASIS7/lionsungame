const FPS_STEP_LIMIT = 0.05;
const UP = Object.freeze({ x: 0, y: -1 });
const DOWN = Object.freeze({ x: 0, y: 1 });
const LEFT = Object.freeze({ x: -1, y: 0 });
const RIGHT = Object.freeze({ x: 1, y: 0 });
const STOP = Object.freeze({ x: 0, y: 0 });
const DIRECTIONS = [UP, LEFT, DOWN, RIGHT];

const COLORS = {
  ink: "#f2efdd", gold: "#ffbe2d", goldLight: "#ffe25b",
  bg: "#060c1b", panel: "#0a162b", board: "#041324"
};

const LEVELS = [
  {
    name: "Kashi Palace", tileBlue: "#135ca0", tileAccent: "#22c6c3", sandstone: "#b46f30",
    rows: [
      "###################", "#o.......#.......o#", "#.##.###.#.###.##.#", "#.................#",
      "#.##.#.#####.#.##.#", "#....#...#...#....#", "####.### # ###.####", "   #.#       #.#   ",
      "####.# ##=## #.####", "    ..#1234#...    ", "####.# ##### #.####", "   #.#       #.#   ",
      "####.# ##### #.####", "#........#........#", "#.##.###.#.###.##.#", "#o.#.....P.....#.o#",
      "##.#.#.#####.#.#.##", "#....#...#...#....#", "#.######.#.######.#", "#.................#",
      "###################"
    ]
  },
  {
    name: "Copper Labyrinth", tileBlue: "#13747a", tileAccent: "#45d6af", sandstone: "#a15b2f",
    rows: [
      "#########################", "#o#.#.....#.....#.....#o#", "#.#.#.###.#.###.#.#...#.#", "#...........#.#.....#...#",
      "#.###.#.###.#.#####.###.#", "#...#.....#.#...#.#...#.#", "###.#.###.#.#.#.#.###.###", "#.#...#.#.#.2.#.....#...#",
      "#.#.#.#.#1#.###3##.####.#", "#.#.....#...#...#.....#.#", "#...#.#####4###.#.###.#.#", "#...#.....#.#.....#.#...#",
      "#.#######.#.#.#.###.###.#", "#.#.....#.....#...#.....#", "#.###.#.###.#.#.#.#.##.##", "#o..........P...#......o#",
      "#########################"
    ]
  },
  {
    name: "Crimson Citadel", tileBlue: "#742045", tileAccent: "#e75b7e", sandstone: "#bf7e3a",
    rows: [
      "#########################", "#o..............#......o#", "###.#...#.#####.###.###.#", "#.#...#...#.......#...#.#",
      "#.#.#####.#..####.#####.#", "#...#...#.#.....#.#.....#", "#.###.#.#.#.###.#.#.#.###", "#.....#.#.#.2.3.#.#.....#",
      "#.#.###.#1###.#...###.#.#", "#.#.#.#.#...#.#.#...#.#.#", "#.#.#.#.###4#.#####.###.#", "#...#.......#.#...#.....#",
      "#####.#######.#.#.#...#.#", "#.......#...#.........#.#", "#.###...#...#.####.##.#.#", "#o..#.....#.P.........#o#",
      "#########################"
    ]
  },
  {
    name: "Sapphire Oasis", tileBlue: "#0f4e78", tileAccent: "#20ccd7", sandstone: "#8c5f2d",
    rows: [
      "#########################", "#o..#.........#.......#o#", "###.#...#.###.#...###.#.#", "#.#.#.#.....#...#.#...#.#",
      "#.#.#.#####.#####.###.#.#", "#.#.#...........#...#...#", "#.#.#####.##.##.###.###.#", "#.#.#...#.1.2.#.#.......#",
      "#.#.#.#.#####3#.#.###.#.#", "#...#.#.....4.....#...#.#", "#.#.#.#####.#.#.###.###.#", "#...#.#...#.....#...#...#",
      "#.#.#...#...#####.###.#.#", "#...#.....#.....#.#.....#", "#.#######.#####...#.###.#", "#o........#.P.....#....o#",
      "#########################"
    ]
  },
  {
    name: "Golden Empire", tileBlue: "#784b14", tileAccent: "#ffcd32", sandstone: "#be6e1e",
    rows: [
      "#########################", "#o..........#.....#....o#", "####.######.#.#####.#.#.#", "#.....#...#.#.....#.#...#",
      "#..##.#.#.#.#.###.#.#.#.#", "#...#.#.#.#...#.#...#.#.#", "###.#.#.###.#...#####.###", "#...#...#.1.#.3...#.#...#",
      "#.#.#####.###2#...#.###.#", "#.#.#.....#.4...#.....#.#", "#.###.##..#.#.#.#.#####.#", "#...#.#.........#.#.....#",
      "###.#.#####.#.#.###.###.#", "#...#...#.......#...#...#", "#.#####.#.##..#...###.#.#", "#o..........P.....#....o#",
      "#########################"
    ]
  }
];

const State = Object.freeze({ START: "start", PLAYING: "playing", DYING: "dying", WON: "won", PAUSED: "paused", LEVEL_CLEAR: "level-clear" });
const GhostMode = Object.freeze({ CHASE: "chase", FRIGHTENED: "frightened", RESPAWNING: "respawning" });

const canvas = document.querySelector("#game");
const ctx = canvas.getContext("2d", { alpha: false, desynchronized: true });
const loading = document.querySelector("#loading");
let viewW = 720, viewH = 1280, dpr = 1;

function keyOf(x, y) { return `${x},${y}`; }
function sameDir(a, b) { return a.x === b.x && a.y === b.y; }
function reverseOf(a) { return { x: -a.x, y: -a.y }; }
function isReverse(a, b) { return a.x === -b.x && a.y === -b.y; }
function clamp(n, a, b) { return Math.max(a, Math.min(b, n)); }
function padScore(n) { return String(n).padStart(5, "0"); }

function roundedRect(context, x, y, w, h, r) {
  r = Math.min(r, w / 2, h / 2);
  context.beginPath();
  context.moveTo(x + r, y);
  context.arcTo(x + w, y, x + w, y + h, r);
  context.arcTo(x + w, y + h, x, y + h, r);
  context.arcTo(x, y + h, x, y, r);
  context.arcTo(x, y, x + w, y, r);
  context.closePath();
}

function fillRound(x, y, w, h, r, fill, stroke = null, lineWidth = 1) {
  roundedRect(ctx, x, y, w, h, r);
  if (fill) { ctx.fillStyle = fill; ctx.fill(); }
  if (stroke) { ctx.lineWidth = lineWidth; ctx.strokeStyle = stroke; ctx.stroke(); }
}

function loadImage(src) {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.decoding = "async";
    image.onload = () => resolve(image);
    image.onerror = reject;
    image.src = src;
  });
}

const ASSET_RECTS = {
  lions: [{ x: 0, y: 65, w: 420, h: 290 }, { x: 420, y: 64, w: 420, h: 291 }],
  clerics: [
    { x: 0, y: 3, w: 280, h: 273 }, { x: 285, y: 0, w: 270, h: 280 },
    { x: 10, y: 280, w: 260, h: 280 }, { x: 280, y: 280, w: 280, h: 280 }
  ],
  iran: { x: 0, y: 0, w: 520, h: 479 }
};

const assets = {};
const frightenedClerics = [];
let memorials = [];

async function loadAssets() {
  const [lion, clerics, iran, flag, names] = await Promise.all([
    loadImage("assets/lion-sprites.webp"), loadImage("assets/clerics-sheet.webp"),
    loadImage("assets/iran-power.webp"), loadImage("assets/lion-sun-flag.webp"),
    fetch("assets/memorials.json").then(r => r.json())
  ]);
  Object.assign(assets, { lion, clerics, iran, flag });
  for (const source of ASSET_RECTS.clerics) {
    const layer = document.createElement("canvas");
    layer.width = source.w; layer.height = source.h;
    const layerCtx = layer.getContext("2d");
    layerCtx.drawImage(clerics, source.x, source.y, source.w, source.h, 0, 0, source.w, source.h);
    layerCtx.globalCompositeOperation = "source-atop";
    layerCtx.fillStyle = "rgba(72,120,255,.62)";
    layerCtx.fillRect(0, 0, source.w, source.h);
    frightenedClerics.push(layer);
  }
  memorials = names;
}

function connectTelegram() {
  const initialize = () => {
    window.Telegram?.WebApp?.ready(); window.Telegram?.WebApp?.expand();
    window.Telegram?.WebApp?.setHeaderColor?.("#060c1b");
    window.Telegram?.WebApp?.setBackgroundColor?.("#060c1b");
  };
  if (window.Telegram?.WebApp) { initialize(); return; }
  const script = document.createElement("script");
  script.src = "telegram-web-app.js"; script.async = true; script.onload = initialize;
  document.head.appendChild(script);
}

class Maze {
  constructor(rows) {
    this.rows = rows;
    this.width = rows[0].length;
    this.height = rows.length;
    this.playerSpawn = { x: 1, y: 1 };
    this.ghostSpawns = {};
    this.initialPellets = new Set();
    this.initialPower = new Set();
    rows.forEach((row, y) => [...row].forEach((tile, x) => {
      if (tile === "P") this.playerSpawn = { x, y };
      else if (/^[1-4]$/.test(tile)) this.ghostSpawns[Number(tile)] = { x, y };
      else if (tile === ".") this.initialPellets.add(keyOf(x, y));
      else if (tile === "o") this.initialPower.add(keyOf(x, y));
    }));
    this.resetCollectibles();
  }

  resetCollectibles() {
    this.pellets = new Set(this.initialPellets);
    this.powerPellets = new Set(this.initialPower);
  }

  tileAt(x, y) {
    if (y < 0 || y >= this.height) return "#";
    return this.rows[y][((x % this.width) + this.width) % this.width];
  }

  passable(x, y, forGhost = false) {
    const tile = this.tileAt(x, y);
    return tile !== "#" && (tile !== "=" || forGhost);
  }

  neighbor(tile, direction) {
    return { x: ((tile.x + direction.x) % this.width + this.width) % this.width, y: tile.y + direction.y };
  }

  legalDirections(tile, forGhost = false) {
    return DIRECTIONS.filter(direction => {
      const n = this.neighbor(tile, direction);
      return this.passable(n.x, n.y, forGhost);
    });
  }

  distance(start, goal) {
    goal = { x: ((goal.x % this.width) + this.width) % this.width, y: clamp(goal.y, 0, this.height - 1) };
    const queue = [[start, 0]];
    const visited = new Set([keyOf(start.x, start.y)]);
    for (let head = 0; head < queue.length; head++) {
      const [tile, distance] = queue[head];
      if (tile.x === goal.x && tile.y === goal.y) return distance;
      for (const direction of DIRECTIONS) {
        const next = this.neighbor(tile, direction);
        const key = keyOf(next.x, next.y);
        if (!visited.has(key) && this.passable(next.x, next.y, true)) {
          visited.add(key); queue.push([next, distance + 1]);
        }
      }
    }
    return Math.abs(start.x - goal.x) + Math.abs(start.y - goal.y) + 100;
  }
}

class Game {
  constructor() {
    this.currentLevel = 0;
    this.maze = new Maze(LEVELS[0].rows);
    this.state = State.START;
    this.score = 0;
    this.highScore = Number(localStorage.getItem("lionSunHighScore") || 0);
    this.lives = 3;
    this.desiredDirection = LEFT;
    this.playerFacing = LEFT;
    this.frightenedTimer = 0;
    this.frightenedChain = 0;
    this.superMode = false;
    this.superBannerTimer = 0;
    this.stateTimer = 0;
    this.animationTime = 0;
    this.floatingTexts = [];
    this.javidPopupTimer = 0;
    this.activeJavidText = "";
    this.javidPool = [];
    this.touchStart = null;
    this.boardOrigin = { x: 0, y: 0 };
    this.panel = { x: 0, y: 0, w: 0, h: 0 };
    this.resetActors();
    this.updateLayout();
  }

  isPowerActive() { return this.frightenedTimer > 0; }

  newGame() {
    this.score = 0; this.lives = 3; this.frightenedTimer = 0; this.frightenedChain = 0;
    this.superMode = false; this.superBannerTimer = 0; this.currentLevel = 0;
    this.loadLevel(0); this.state = State.PLAYING;
  }

  loadLevel(index) {
    this.currentLevel = index;
    this.maze = new Maze(LEVELS[index].rows);
    this.updateLayout(); this.resetActors();
  }

  nextLevel() {
    if (this.currentLevel + 1 >= LEVELS.length) { this.state = State.WON; return; }
    this.loadLevel(this.currentLevel + 1);
    this.frightenedTimer = 0; this.frightenedChain = 0; this.state = State.PLAYING;
  }

  resetActors() {
    const p = this.maze.playerSpawn;
    this.player = { x: p.x, y: p.y, direction: LEFT, speed: 5.35 };
    this.desiredDirection = LEFT; this.playerFacing = LEFT;
    const defs = [
      [1, "Chaser", "chaser", "#e03f4d", { x: this.maze.width - 2, y: 1 }],
      [2, "Ambusher", "ambusher", "#ec57a8", { x: 1, y: 1 }],
      [3, "Wanderer", "random", "#33c1d4", { x: this.maze.width - 2, y: this.maze.height - 2 }],
      [4, "Shy", "shy", "#f68e34", { x: 1, y: this.maze.height - 2 }]
    ];
    this.ghosts = defs.map(([number, name, personality, color, scatterTarget]) => {
      const spawn = this.maze.ghostSpawns[number];
      return { x: spawn.x, y: spawn.y, direction: number === 4 ? UP : LEFT, speed: 4.65,
        name, personality, color, spawn: { ...spawn }, scatterTarget, mode: GhostMode.CHASE, respawnTimer: 0 };
    });
  }

  updateLayout() {
    const width = viewW, height = viewH;
    const gap = Math.max(14, Math.min(26, Math.floor(width / 75)));
    if (height > width) {
      const margin = Math.max(12, Math.floor(width / 45));
      const panelHeight = Math.max(280, Math.min(340, Math.floor(height * .26)));
      const usableWidth = width - margin * 2;
      const usableHeight = height - panelHeight - gap - margin * 3;
      this.tileSize = Math.max(14, Math.floor(Math.min(usableWidth / this.maze.width, usableHeight / this.maze.height)));
      const boardWidth = this.maze.width * this.tileSize;
      const boardHeight = this.maze.height * this.tileSize;
      const groupHeight = boardHeight + gap + panelHeight;
      const originX = Math.floor((width - boardWidth) / 2);
      const originY = Math.max(margin, Math.floor((height - groupHeight) / 2));
      this.boardOrigin = { x: originX, y: originY };
      this.panel = { x: margin, y: originY + boardHeight + gap, w: width - margin * 2, h: panelHeight };
    } else {
      const panelWidth = Math.max(250, Math.min(350, Math.floor(width * .19)));
      const usableWidth = width - panelWidth - gap - 40;
      const usableHeight = height - 40;
      this.tileSize = Math.max(16, Math.floor(Math.min(usableWidth / this.maze.width, usableHeight / this.maze.height)));
      const boardWidth = this.maze.width * this.tileSize;
      const boardHeight = this.maze.height * this.tileSize;
      const groupWidth = boardWidth + gap + panelWidth;
      const originX = Math.max(12, Math.floor((width - groupWidth) / 2));
      const originY = Math.max(12, Math.floor((height - boardHeight) / 2));
      this.boardOrigin = { x: originX, y: originY };
      this.panel = { x: originX + boardWidth + gap, y: originY, w: panelWidth, h: boardHeight };
    }
  }

  loseLife() {
    if (this.state !== State.PLAYING || this.superMode) return;
    this.lives--; this.frightenedTimer = 0; this.state = State.DYING; this.stateTimer = 1.35;
  }

  activateSuperMode() {
    this.superMode = true; this.superBannerTimer = 3.25; this.score += 1000;
    this.resetActors(); this.frightenedTimer = 8; this.frightenedChain = 0;
    this.ghosts.forEach(g => g.mode = GhostMode.FRIGHTENED);
    this.state = State.PLAYING;
  }

  setDirection(direction) { this.desiredDirection = direction; }

  update(dt) {
    this.animationTime += dt;
    this.superBannerTimer = Math.max(0, this.superBannerTimer - dt);
    this.javidPopupTimer = Math.max(0, this.javidPopupTimer - dt);
    this.floatingTexts.forEach(ft => ft.timer -= dt);
    this.floatingTexts = this.floatingTexts.filter(ft => ft.timer > 0);

    if (this.state === State.DYING) {
      this.stateTimer -= dt;
      if (this.stateTimer <= 0) {
        if (this.lives <= 0) this.activateSuperMode();
        else { this.resetActors(); this.state = State.PLAYING; }
      }
      return;
    }
    if (this.state !== State.PLAYING) return;

    this.frightenedTimer = Math.max(0, this.frightenedTimer - dt);
    if (!this.isPowerActive()) {
      this.ghosts.forEach(g => { if (g.mode === GhostMode.FRIGHTENED) g.mode = GhostMode.CHASE; });
    }
    this.updatePlayer(dt); this.collectAtPlayer(); this.updateGhosts(dt); this.resolveCollisions();
    if (this.score > this.highScore) {
      this.highScore = this.score;
      try { localStorage.setItem("lionSunHighScore", String(this.highScore)); } catch (_) {}
    }
    if (!this.maze.pellets.size && !this.maze.powerPellets.size) {
      this.state = this.currentLevel + 1 < LEVELS.length ? State.LEVEL_CLEAR : State.WON;
    }
  }

  actorTile(actor) { return { x: Math.round(actor.x), y: Math.round(actor.y) }; }
  atTileCenter(actor) { return Math.abs(actor.x - Math.round(actor.x)) < .0001 && Math.abs(actor.y - Math.round(actor.y)) < .0001; }

  updatePlayer(dt) {
    const p = this.player;
    if (isReverse(this.desiredDirection, p.direction)) p.direction = this.desiredDirection;
    if (this.atTileCenter(p)) {
      p.x = Math.round(p.x); p.y = Math.round(p.y);
      const tile = this.actorTile(p);
      const desired = this.maze.neighbor(tile, this.desiredDirection);
      if (this.maze.passable(desired.x, desired.y)) p.direction = this.desiredDirection;
      const forward = this.maze.neighbor(tile, p.direction);
      if (!this.maze.passable(forward.x, forward.y)) p.direction = STOP;
    }
    if (!sameDir(p.direction, STOP)) this.playerFacing = p.direction;
    this.advanceActor(p, p.speed * dt); this.wrapActor(p);
  }

  collectAtPlayer() {
    const tile = this.actorTile(this.player), key = keyOf(tile.x, tile.y);
    if (this.maze.pellets.delete(key)) {
      this.score += 10; this.floatingTexts.push({ x: tile.x, y: tile.y, text: "+10", color: "#ffee71", timer: 1 });
    }
    if (this.maze.powerPellets.delete(key)) {
      this.score += 50; this.floatingTexts.push({ x: tile.x, y: tile.y, text: "+50", color: "#ffbe2d", timer: 1 });
      this.frightenedTimer = 8; this.frightenedChain = 0;
      this.ghosts.forEach(g => {
        if (g.mode !== GhostMode.RESPAWNING) { g.mode = GhostMode.FRIGHTENED; g.direction = reverseOf(g.direction); }
      });
    }
  }

  updateGhosts(dt) {
    for (const ghost of this.ghosts) {
      if (ghost.mode === GhostMode.RESPAWNING) {
        ghost.respawnTimer -= dt;
        if (ghost.respawnTimer <= 0) {
          ghost.x = ghost.spawn.x; ghost.y = ghost.spawn.y; ghost.direction = UP;
          // The global power timer is authoritative. A cleric returning while
          // it is active must still be blue and edible until that timer ends.
          ghost.mode = this.isPowerActive() ? GhostMode.FRIGHTENED : GhostMode.CHASE;
        }
        continue;
      }
      if (this.atTileCenter(ghost)) {
        ghost.x = Math.round(ghost.x); ghost.y = Math.round(ghost.y);
        this.chooseGhostDirection(ghost);
      }
      const speed = ghost.mode === GhostMode.FRIGHTENED ? 3.35 : ghost.speed;
      this.advanceActor(ghost, speed * dt); this.wrapActor(ghost);
    }
  }

  advanceActor(actor, distance) {
    const oldX = actor.x, oldY = actor.y;
    actor.x += actor.direction.x * distance; actor.y += actor.direction.y * distance;
    if (actor.direction.x && Math.abs(oldX - Math.round(oldX)) > .0001) {
      const center = actor.direction.x < 0 ? Math.floor(oldX) : Math.ceil(oldX);
      if (actor.direction.x < 0 ? actor.x <= center : actor.x >= center) actor.x = center;
    }
    if (actor.direction.y && Math.abs(oldY - Math.round(oldY)) > .0001) {
      const center = actor.direction.y < 0 ? Math.floor(oldY) : Math.ceil(oldY);
      if (actor.direction.y < 0 ? actor.y <= center : actor.y >= center) actor.y = center;
    }
  }

  chooseGhostDirection(ghost) {
    const tile = this.actorTile(ghost), reverse = reverseOf(ghost.direction);
    let choices = this.maze.legalDirections(tile, true);
    const nonReverse = choices.filter(c => !sameDir(c, reverse));
    if (nonReverse.length) choices = nonReverse;
    if (!choices.length) { ghost.direction = reverse; return; }
    if (ghost.mode === GhostMode.FRIGHTENED || ghost.personality === "random") {
      ghost.direction = choices[Math.floor(Math.random() * choices.length)]; return;
    }
    const target = this.ghostTarget(ghost);
    const ranked = choices.map(direction => ({ direction, distance: this.maze.distance(this.maze.neighbor(tile, direction), target), tie: Math.random() }));
    ranked.sort((a, b) => a.distance - b.distance || a.tie - b.tie);
    ghost.direction = ranked[0].direction;
  }

  ghostTarget(ghost) {
    const p = this.actorTile(this.player), d = this.player.direction;
    if (ghost.personality === "chaser") return p;
    if (ghost.personality === "ambusher") return { x: p.x + d.x * 4, y: p.y + d.y * 4 };
    if (ghost.personality === "shy") {
      const distance = Math.abs(ghost.x - this.player.x) + Math.abs(ghost.y - this.player.y);
      return distance < 6 ? ghost.scatterTarget : p;
    }
    return ghost.scatterTarget;
  }

  nextMemorial() {
    if (!this.javidPool.length) {
      this.javidPool = [...memorials];
      for (let i = this.javidPool.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [this.javidPool[i], this.javidPool[j]] = [this.javidPool[j], this.javidPool[i]];
      }
    }
    return this.javidPool.pop() || "";
  }

  resolveCollisions() {
    for (const ghost of this.ghosts) {
      if (ghost.mode === GhostMode.RESPAWNING) continue;
      const dx = Math.abs(this.player.x - ghost.x), dy = this.player.y - ghost.y;
      const wrappedDx = Math.min(dx, this.maze.width - dx);
      if (Math.min(Math.hypot(dx, dy), Math.hypot(wrappedDx, dy)) >= .68) continue;
      if (ghost.mode === GhostMode.FRIGHTENED || this.isPowerActive() || this.superMode) {
        const base = this.superMode ? 500 : 200;
        this.score += base * (2 ** this.frightenedChain);
        this.activeJavidText = this.nextMemorial(); this.javidPopupTimer = 5;
        this.floatingTexts.push({ x: ghost.x, y: ghost.y, text: "ملا پر!", color: "#ff7878", timer: .8 });
        this.frightenedChain = Math.min(3, this.frightenedChain + 1);
        ghost.mode = GhostMode.RESPAWNING; ghost.respawnTimer = 2;
      } else { this.loseLife(); break; }
    }
  }

  wrapActor(actor) {
    if (actor.x < -.55) actor.x = this.maze.width - .45;
    else if (actor.x > this.maze.width - .45) actor.x = -.55;
  }

  tileCenter(tile) {
    return { x: this.boardOrigin.x + (tile.x + .5) * this.tileSize, y: this.boardOrigin.y + (tile.y + .5) * this.tileSize };
  }

  draw() {
    this.drawBackground(); this.drawMaze(); this.drawCollectibles();
    if (this.state !== State.DYING || Math.floor(this.stateTimer * 10) % 2 === 0) this.drawLion();
    this.ghosts.forEach((g, i) => { if (g.mode !== GhostMode.RESPAWNING) this.drawCleric(g, i); });
    this.drawFloatingTexts(); this.drawMemorialPopup();
    if (this.superMode) this.drawSuperScreenEffect();
    this.drawHud();
    if (this.state === State.START) this.drawOverlay("LION & SUN MAZE", "Collect every sun. Reclaim all three maps.", "Press ENTER or tap to start");
    else if (this.state === State.PAUSED) this.drawOverlay("PAUSED", "", "Press P to continue");
    else if (this.state === State.LEVEL_CLEAR) this.drawOverlay("MAP CLEARED!", `Score: ${this.score}`, "Press ENTER or tap for the next map");
    else if (this.state === State.WON) this.drawVictoryOverlay();
    else if (this.superBannerTimer > 0) this.drawSuperBanner();
  }

  drawBackground() {
    ctx.fillStyle = "#060c1b"; ctx.fillRect(0, 0, viewW, viewH);
    const step = Math.max(72, Math.floor(viewH / 11));
    ctx.strokeStyle = "#121f38"; ctx.lineWidth = 1;
    for (let y = -step; y < viewH + step; y += step) {
      for (let x = -step; x < viewW + step; x += step) {
        const cx = x + ((Math.floor(y / step) & 1) ? step / 2 : 0);
        ctx.beginPath(); ctx.arc(cx, y, step / 3, 0, Math.PI * 2); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(cx, y - step / 4); ctx.lineTo(cx + step / 4, y); ctx.lineTo(cx, y + step / 4); ctx.lineTo(cx - step / 4, y); ctx.closePath(); ctx.stroke();
      }
    }
  }

  drawMaze() {
    const spec = LEVELS[this.currentLevel], t = this.tileSize, ox = this.boardOrigin.x, oy = this.boardOrigin.y;
    const bw = this.maze.width * t, bh = this.maze.height * t;
    fillRound(ox + 7, oy + 8, bw, bh, Math.max(8, t / 3), "#000");
    fillRound(ox, oy, bw, bh, Math.max(8, t / 3), "#041324", spec.sandstone, Math.max(3, t / 10));
    this.maze.rows.forEach((row, y) => [...row].forEach((tile, x) => {
      if (tile === "#") {
        const rx = ox + x * t + 1, ry = oy + y * t + 1, rw = t - 2, rh = t - 2, r = Math.max(3, t / 8);
        fillRound(rx + 2, ry + 3, rw, rh, r, "#402314");
        fillRound(rx, ry, rw, rh, r, spec.sandstone);
        const inset = Math.max(4, t / 8), ix = rx + inset / 2, iy = ry + inset / 2, iw = rw - inset, ih = rh - inset;
        fillRound(ix, iy, iw, ih, Math.max(2, t / 10), null, "#d39d4f", 1);
        const bhh = Math.max(4, ih / 3);
        fillRound(ix + 1, iy + 1, iw - 2, bhh, Math.max(2, t / 12), spec.tileBlue);
        ctx.strokeStyle = spec.tileAccent; ctx.lineWidth = Math.max(1, t / 24); ctx.beginPath(); ctx.moveTo(ix + 3, iy + bhh - 2); ctx.lineTo(ix + iw - 3, iy + bhh - 2); ctx.stroke();
        if (t >= 34) {
          const cx = ix + iw / 2, cy = iy + 1 + bhh / 2, radius = Math.max(2, t / 12);
          ctx.strokeStyle = COLORS.goldLight; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(cx, cy - radius); ctx.lineTo(cx + radius, cy); ctx.lineTo(cx, cy + radius); ctx.lineTo(cx - radius, cy); ctx.closePath(); ctx.stroke();
        }
        ctx.strokeStyle = "#754422"; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(rx + 2, ry + rh / 2); ctx.lineTo(rx + rw - 2, ry + rh / 2); ctx.stroke();
      } else if (tile === "=") {
        const c = this.tileCenter({ x, y });
        ctx.strokeStyle = "#ff8bcd"; ctx.lineWidth = Math.max(4, t / 9); ctx.beginPath(); ctx.moveTo(c.x - t / 2 + 5, c.y); ctx.lineTo(c.x + t / 2 - 5, c.y); ctx.stroke();
      }
    }));
  }

  drawSun(center, size) {
    ctx.save(); ctx.translate(center.x, center.y); ctx.lineCap = "round";
    const outer = Math.max(5, size / 2), inner = Math.max(3, outer * .58);
    ctx.strokeStyle = "rgba(255,161,23,.92)"; ctx.lineWidth = Math.max(1, size / 10);
    for (let i = 0; i < 12; i++) { const a = Math.PI * 2 * i / 12; ctx.beginPath(); ctx.moveTo(Math.cos(a) * inner, Math.sin(a) * inner); ctx.lineTo(Math.cos(a) * outer, Math.sin(a) * outer); ctx.stroke(); }
    ctx.fillStyle = "rgba(255,129,12,.35)"; ctx.beginPath(); ctx.arc(0, 0, inner + Math.max(2, size / 7), 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#ffbc23"; ctx.beginPath(); ctx.arc(0, 0, inner, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#ffee71"; ctx.beginPath(); ctx.arc(-inner / 4, -inner / 4, Math.max(2, inner / 2), 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = "#c45b0b"; ctx.lineWidth = Math.max(1, size / 12); ctx.beginPath(); ctx.arc(0, 0, inner, 0, Math.PI * 2); ctx.stroke(); ctx.restore();
  }

  drawCollectibles() {
    const size = Math.max(14, this.tileSize * .43);
    this.maze.pellets.forEach(key => { const [x, y] = key.split(",").map(Number); this.drawSun(this.tileCenter({ x, y }), size); });
    const pulse = 1 + .1 * Math.sin(this.animationTime * 6), powerSize = Math.max(46, this.tileSize * 1.42 * pulse);
    this.maze.powerPellets.forEach(key => { const [x, y] = key.split(",").map(Number); this.drawImageFit(assets.iran, ASSET_RECTS.iran, this.tileCenter({ x, y }), powerSize); });
  }

  drawImageFit(image, source, center, boxSize, options = {}) {
    const scale = Math.min(boxSize / source.w, boxSize / source.h), w = source.w * scale, h = source.h * scale;
    ctx.save(); ctx.translate(center.x, center.y); if (options.rotate) ctx.rotate(options.rotate); if (options.flipX) ctx.scale(-1, 1);
    if (options.alpha != null) ctx.globalAlpha = options.alpha;
    ctx.drawImage(image, source.x, source.y, source.w, source.h, -w / 2, -h / 2, w, h);
    if (options.tint) { ctx.globalCompositeOperation = "source-atop"; ctx.fillStyle = options.tint; ctx.fillRect(-w / 2, -h / 2, w, h); }
    ctx.restore();
  }

  drawLion() {
    const center = this.tileCenter(this.player), size = Math.max(74, this.tileSize * 2.55);
    const moving = !sameDir(this.player.direction, STOP) && this.state === State.PLAYING;
    const frame = moving ? Math.floor(this.animationTime * 7.5) % 2 : 0;
    if (this.superMode || this.isPowerActive()) this.drawSuperAura(center, size);
    ctx.fillStyle = "rgba(0,0,0,.42)"; ctx.beginPath(); ctx.ellipse(center.x, center.y + size * .34, size * .28, Math.max(3, size * .07), 0, 0, Math.PI * 2); ctx.fill();
    let rotate = 0, flipX = false;
    if (sameDir(this.playerFacing, RIGHT)) flipX = true;
    else if (sameDir(this.playerFacing, UP)) rotate = Math.PI / 2;
    else if (sameDir(this.playerFacing, DOWN)) rotate = -Math.PI / 2;
    this.drawImageFit(assets.lion, ASSET_RECTS.lions[frame], center, size, { rotate, flipX });
  }

  drawSuperAura(center, size) {
    ctx.save(); ctx.translate(center.x, center.y); ctx.lineCap = "round";
    const rotation = this.animationTime * .65, inner = size * .34, outer = size * .78;
    ctx.strokeStyle = "rgba(255,181,34,.57)"; ctx.lineWidth = Math.max(2, size / 28);
    for (let i = 0; i < 32; i++) { const a = Math.PI * 2 * i / 32 + rotation, len = i % 2 === 0 ? outer : outer * .78; ctx.beginPath(); ctx.moveTo(Math.cos(a) * inner, Math.sin(a) * inner); ctx.lineTo(Math.cos(a) * len, Math.sin(a) * len); ctx.stroke(); }
    ctx.fillStyle = "rgba(255,126,10,.23)"; ctx.beginPath(); ctx.arc(0, 0, size * .48, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "rgba(255,201,55,.33)"; ctx.beginPath(); ctx.arc(0, 0, inner, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = "rgba(255,239,132,.71)"; ctx.lineWidth = Math.max(2, size / 35); ctx.beginPath(); ctx.arc(0, 0, inner * .74, 0, Math.PI * 2); ctx.stroke();
    for (let i = 0; i < 14; i++) { const a = rotation * 1.9 + i * Math.PI * 2 / 14, orbit = size * (.5 + .2 * Math.sin(this.animationTime * 2.2 + i)); ctx.fillStyle = "rgba(255,231,104,.86)"; ctx.beginPath(); ctx.arc(Math.cos(a) * orbit, Math.sin(a) * orbit, Math.max(2, size / 30 + i % 3), 0, Math.PI * 2); ctx.fill(); }
    ctx.restore();
  }

  drawCleric(ghost, index) {
    const center = this.tileCenter(ghost), size = Math.max(62, this.tileSize * 1.86);
    const frightened = ghost.mode === GhostMode.FRIGHTENED || this.isPowerActive();
    const flashing = frightened && this.frightenedTimer < 2 && Math.floor(this.frightenedTimer * 8) % 2 === 0;
    const auraSize = size * (1.08 + .06 * Math.sin(this.animationTime * 5 + index));
    ctx.fillStyle = frightened ? "rgba(41,103,255,.16)" : "rgba(229,28,45,.16)"; ctx.beginPath(); ctx.arc(center.x, center.y, auraSize / 2, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = frightened ? "rgba(41,103,255,.31)" : "rgba(229,28,45,.31)"; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(center.x, center.y, auraSize / 3, 0, Math.PI * 2); ctx.stroke();
    ctx.fillStyle = "rgba(0,0,0,.4)"; ctx.beginPath(); ctx.ellipse(center.x, center.y + size * .34, size * .26, Math.max(3, size * .055), 0, 0, Math.PI * 2); ctx.fill();
    if (frightened && !flashing) {
      const image = frightenedClerics[index];
      this.drawImageFit(image, { x: 0, y: 0, w: image.width, h: image.height }, center, size);
    } else {
      this.drawImageFit(assets.clerics, ASSET_RECTS.clerics[index], center, size);
    }
  }

  drawFloatingTexts() {
    ctx.textAlign = "center"; ctx.textBaseline = "middle"; ctx.font = `${Math.max(22, viewH / 36)}px LionSunPersian`;
    for (const ft of this.floatingTexts) { const p = this.tileCenter(ft); ctx.fillStyle = ft.color; ctx.fillText(ft.text, p.x, p.y); }
  }

  fitText(text, maxWidth, startSize, minSize = 14, family = "LionSunPersian") {
    let size = startSize;
    while (size > minSize) { ctx.font = `${size}px ${family}`; if (ctx.measureText(text).width <= maxWidth) break; size--; }
    return size;
  }

  drawMemorialPopup() {
    if (this.javidPopupTimer <= 0 || !this.activeJavidText) return;
    const w = Math.min(680, viewW - 40), h = 84, x = 20, y = 20;
    ctx.save(); roundedRect(ctx, x, y, w, h, 18); ctx.clip();
    ctx.fillStyle = "rgba(15,30,55,.84)"; ctx.fillRect(x, y, w, h);
    ctx.globalAlpha = .165; ctx.drawImage(assets.flag, x, y, w, h); ctx.globalAlpha = 1;
    ctx.direction = "rtl"; ctx.textAlign = "right"; ctx.textBaseline = "middle";
    ctx.fillStyle = COLORS.goldLight; ctx.font = `${Math.max(18, viewH / 42)}px LionSunPersian`; ctx.fillText("یادبود جاویدنامان", x + w - 15, y + 21);
    const size = this.fitText(this.activeJavidText, w - 30, Math.max(14, viewH / 34));
    ctx.font = `${size}px LionSunPersian`; ctx.fillStyle = COLORS.ink; ctx.fillText(this.activeJavidText, x + w - 15, y + 59);
    ctx.restore(); fillRound(x, y, w, h, 18, null, "rgba(255,190,45,.9)", 2);
  }

  drawSuperScreenEffect() {
    const pulse = (55 + 22 * Math.sin(this.animationTime * 4)) / 255, border = Math.max(6, viewH / 90);
    fillRound(border / 2, border / 2, viewW - border, viewH - border, 20, null, `rgba(255,177,31,${pulse})`, border);
    fillRound(border * 2.5, border * 2.5, viewW - border * 5, viewH - border * 5, 18, null, `rgba(255,232,115,${pulse / 2})`, 2);
  }

  panelFrame(panel, spec) {
    fillRound(panel.x + 5, panel.y + 6, panel.w, panel.h, 22, "#000");
    fillRound(panel.x, panel.y, panel.w, panel.h, 22, COLORS.panel, spec.sandstone, 3);
    fillRound(panel.x + 7, panel.y + 7, panel.w - 14, panel.h - 14, 16, null, spec.tileBlue, 2);
  }

  drawHud() {
    const p = this.panel, spec = LEVELS[this.currentLevel]; this.panelFrame(p, spec);
    if (p.w > p.h * 1.45) this.drawHudPortrait(p, spec); else this.drawHudSide(p, spec);
  }

  text(text, x, y, size, color, align = "center", family = "Arial") {
    ctx.font = `${Math.round(size)}px ${family}`; ctx.fillStyle = color; ctx.textAlign = align; ctx.textBaseline = "middle"; ctx.direction = "ltr"; ctx.fillText(text, x, y);
  }

  drawHudPortrait(p, spec) {
    const top = p.y + 22, remaining = this.maze.pellets.size + this.maze.powerPellets.size;
    const total = this.maze.initialPellets.size + this.maze.initialPower.size;
    this.text(`MAP ${this.currentLevel + 1} / ${LEVELS.length}`, p.x + p.w / 2, top, Math.max(22, viewH / 36), COLORS.goldLight);
    this.text(spec.name, p.x + p.w / 2, top + 38, Math.max(32, viewH / 25), COLORS.ink);
    const ruleY = top + 68; ctx.strokeStyle = spec.tileAccent; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(p.x + 26, ruleY); ctx.lineTo(p.x + p.w - 26, ruleY); ctx.stroke();
    const colY = ruleY + 34, leftX = p.x + p.w / 5, rightX = p.x + p.w * 4 / 5;
    this.text("SCORE", p.x + p.w / 2, colY, Math.max(18, viewH / 48), "#8da4c3");
    this.text(padScore(this.score), p.x + p.w / 2, colY + 38, Math.max(32, viewH / 25), COLORS.goldLight);
    this.text(`BEST  ${padScore(this.highScore)}`, leftX, colY + 4, Math.max(18, viewH / 48), "#bacae0");
    this.text(`SUNS  ${total - remaining}/${total}`, leftX, colY + 36, Math.max(18, viewH / 48), "#bacae0");
    if (this.superMode) {
      this.text("LION & SUN", rightX, colY + 4, Math.max(18, viewH / 48), COLORS.goldLight);
      this.text("IMMORTAL", rightX, colY + 38, Math.max(22, viewH / 36), "#ffeb76");
    } else {
      this.text("LIVES", rightX, colY, Math.max(18, viewH / 48), "#8da4c3");
      const spacing = 38, firstX = rightX - spacing * (this.lives - 1) / 2;
      for (let i = 0; i < this.lives; i++) this.drawImageFit(assets.lion, ASSET_RECTS.lions[0], { x: firstX + i * spacing, y: colY + 43 }, 42);
    }
    this.text("SWIPE TO MOVE   •   TAP TO START / CONTINUE", p.x + p.w / 2, p.y + p.h - 28, Math.max(18, viewH / 48), "#acc0d9");
  }

  drawHudSide(p, spec) {
    const cx = p.x + p.w / 2, total = this.maze.initialPellets.size + this.maze.initialPower.size;
    const remaining = this.maze.pellets.size + this.maze.powerPellets.size;
    this.text(`MAP ${this.currentLevel + 1} / ${LEVELS.length}`, cx, p.y + 30, Math.max(18, viewH / 48), COLORS.goldLight);
    const nameSize = this.fitText(spec.name, p.w - 30, Math.max(32, viewH / 25), 18, "Arial"); this.text(spec.name, cx, p.y + 72, nameSize, COLORS.ink);
    this.text("SCORE", cx, p.y + p.h * .23, Math.max(18, viewH / 48), "#8da4c3");
    this.text(padScore(this.score), cx, p.y + p.h * .32, Math.max(52, viewH / 11), COLORS.goldLight);
    this.text(`BEST   ${padScore(this.highScore)}`, cx, p.y + p.h * .43, Math.max(22, viewH / 36), "#bacae0");
    this.text(`SUNS   ${total - remaining} / ${total}`, cx, p.y + p.h * .49, Math.max(22, viewH / 36), "#bacae0");
    if (this.superMode) { this.text("LION & SUN MODE", cx, p.y + p.h * .6, 22, COLORS.gold); this.text("IMMORTAL", cx, p.y + p.h * .67, 32, "#ffeb76"); }
    else {
      this.text("LIVES", cx, p.y + p.h * .58, 22, "#8da4c3"); const size = Math.max(36, Math.min(62, p.w / 5)), spacing = Math.min(size, (p.w - 42) / 3), first = cx - spacing * (this.lives - 1) / 2;
      for (let i = 0; i < this.lives; i++) this.drawImageFit(assets.lion, ASSET_RECTS.lions[0], { x: first + i * spacing, y: p.y + p.h * .66 }, size);
    }
    this.text("ARROWS / WASD  MOVE", cx, p.y + p.h * .8, 18, "#acc0d9"); this.text("P  PAUSE", cx, p.y + p.h * .85, 18, "#acc0d9"); this.text("F11  FULLSCREEN", cx, p.y + p.h * .9, 18, "#acc0d9");
  }

  drawOverlay(title, subtitle, prompt) {
    ctx.fillStyle = "rgba(4,5,14,.8)"; ctx.fillRect(0, 0, viewW, viewH);
    const w = Math.min(820, viewW - 80), h = Math.min(370, viewH - 80), x = (viewW - w) / 2, y = (viewH - h) / 2, spec = LEVELS[this.currentLevel];
    fillRound(x + 8, y + 9, w, h, 30, "#000"); fillRound(x, y, w, h, 30, "#0c1931", spec.sandstone, 5); fillRound(x + 10, y + 10, w - 20, h - 20, 22, null, spec.tileBlue, 2);
    const titleSize = this.fitText(title, w - 50, Math.max(64, viewH / 11), 28, "Arial"); this.text(title, viewW / 2, y + h * .31, titleSize, COLORS.goldLight);
    this.text(subtitle, viewW / 2, y + h * .56, Math.max(22, viewH / 36), COLORS.ink);
    if (Math.floor(this.animationTime * 2) % 2 === 0 || this.state === State.PAUSED) this.text(prompt, viewW / 2, y + h * .76, Math.max(22, viewH / 36), spec.tileAccent);
  }

  drawSuperBanner() {
    const w = Math.min(880, viewW - 80), h = Math.max(100, viewH / 8), x = (viewW - w) / 2, y = viewH / 5 - h / 2, alpha = Math.min(.92, this.superBannerTimer * .49);
    fillRound(x, y, w, h, 24, `rgba(80,36,5,${alpha})`, `rgba(255,196,50,${alpha})`, 4);
    this.text("THE LION & SUN AWAKENS", viewW / 2, y + h * .4, Math.max(32, viewH / 25), "#fff1a4");
    const persian = "هرگز شیر و خورشید بر ملاها شکست نخواهد خورد"; const size = this.fitText(persian, w - 40, Math.max(24, viewH / 31), 14);
    ctx.direction = "rtl"; this.text(persian, viewW / 2, y + h * .75, size, COLORS.ink, "center", "LionSunPersian");
  }

  drawVictoryOverlay() {
    ctx.fillStyle = "rgba(3,8,18,.88)"; ctx.fillRect(0, 0, viewW, viewH);
    const w = Math.min(940, viewW - 70), h = Math.min(600, viewH - 60), x = (viewW - w) / 2, y = (viewH - h) / 2;
    fillRound(x + 10, y + 12, w, h, 34, "#000"); fillRound(x, y, w, h, 34, "#0f2131", "#e59d20", 6); fillRound(x + 11, y + 11, w - 22, h - 22, 26, null, "#23985e", 3);
    const emblem = { x: viewW / 2, y: y + h * .26 }, emblemSize = Math.min(220, h / 3); this.drawSuperAura(emblem, emblemSize); this.drawImageFit(assets.iran, ASSET_RECTS.iran, emblem, Math.min(190, h / 3));
    this.text("ALL THREE MAPS CLEARED", viewW / 2, y + h * .52, Math.max(32, viewH / 25), "#b3dcbc");
    const msg = "PAHLAVI IS PROUD OF YOU", msgSize = this.fitText(msg, w - 60, Math.max(64, viewH / 11), 24, "Arial"); this.text(msg, viewW / 2, y + h * .65, msgSize, COLORS.goldLight);
    this.text(`FINAL SCORE   ${padScore(this.score)}`, viewW / 2, y + h * .79, Math.max(22, viewH / 36), COLORS.ink);
    if (Math.floor(this.animationTime * 2) % 2 === 0) this.text("Press ENTER or tap to play again", viewW / 2, y + h * .9, Math.max(22, viewH / 36), "#58d8ae");
  }
}

let game;

function resize() {
  const rect = canvas.getBoundingClientRect();
  const portrait = window.innerHeight > window.innerWidth;
  viewW = portrait ? 720 : Math.max(640, Math.round(rect.width));
  viewH = portrait ? 1280 : Math.max(360, Math.round(rect.height));
  dpr = portrait ? 1 : Math.min(window.devicePixelRatio || 1, 2);
  canvas.width = Math.round(viewW * dpr); canvas.height = Math.round(viewH * dpr);
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  if (game) game.updateLayout();
}

function activateOrAdvance() {
  if (!game) return;
  if (game.state === State.START || game.state === State.WON) game.newGame();
  else if (game.state === State.LEVEL_CLEAR) game.nextLevel();
}

window.addEventListener("keydown", event => {
  const key = event.key.toLowerCase();
  const moves = { arrowup: UP, w: UP, arrowdown: DOWN, s: DOWN, arrowleft: LEFT, a: LEFT, arrowright: RIGHT, d: RIGHT };
  if (moves[key]) { event.preventDefault(); game?.setDirection(moves[key]); }
  else if (key === "enter" || key === " ") { event.preventDefault(); activateOrAdvance(); }
  else if (key === "p" && game && (game.state === State.PLAYING || game.state === State.PAUSED)) game.state = game.state === State.PLAYING ? State.PAUSED : State.PLAYING;
  else if (key === "f11") { event.preventDefault(); document.fullscreenElement ? document.exitFullscreen() : document.documentElement.requestFullscreen?.(); }
});

canvas.addEventListener("pointerdown", event => {
  canvas.setPointerCapture?.(event.pointerId); canvas.focus({ preventScroll: true });
  if (game && [State.START, State.WON, State.LEVEL_CLEAR].includes(game.state)) { activateOrAdvance(); game.touchStart = null; return; }
  game.touchStart = { x: event.clientX, y: event.clientY };
});

canvas.addEventListener("pointerup", event => {
  if (!game?.touchStart) return;
  const dx = event.clientX - game.touchStart.x, dy = event.clientY - game.touchStart.y;
  game.touchStart = null;
  if (Math.max(Math.abs(dx), Math.abs(dy)) >= Math.max(18, viewH * .025)) game.setDirection(Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? RIGHT : LEFT) : (dy > 0 ? DOWN : UP));
});

canvas.addEventListener("pointercancel", () => { if (game) game.touchStart = null; });
window.addEventListener("resize", resize, { passive: true });
window.visualViewport?.addEventListener("resize", resize, { passive: true });

let last = performance.now();
function frame(now) {
  const dt = Math.min((now - last) / 1000, FPS_STEP_LIMIT); last = now;
  game.update(dt); game.draw(); requestAnimationFrame(frame);
}

async function boot() {
  try {
    resize(); await loadAssets(); game = new Game();
    // Read-only handle used by the automated browser checks and removable in
    // production without affecting gameplay.
    window.__lionSunGame = game;
    loading.classList.add("done"); canvas.focus(); requestAnimationFrame(frame);
    connectTelegram();
    // Persian text is first needed after a power-up. Fetch its font in the
    // background so it never delays the first playable frame.
    setTimeout(() => document.fonts.load('24px "LionSunPersian"').catch(() => {}), 1500);
  } catch (error) {
    console.error(error); loading.querySelector("p").textContent = "خطا در بارگذاری بازی — صفحه را دوباره باز کنید";
  }
}

boot();

export { Game, Maze, GhostMode, State, LEVELS };
